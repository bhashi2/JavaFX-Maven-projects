import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {

	@Test
	void testBasic() {
		Coffee order = new BasicCoffee();
		double cost = order.makeCoffee();
		assertEquals(3.99, cost, "wrong value");
	}
	
	@Test
	void testCream() {
		Coffee order = new Cream(new BasicCoffee());
		double cost = order.makeCoffee();
		assertEquals(4.49, cost, "wrong value");
	}
	
	@Test
	void testButter() {
		Coffee order = new Butter(new BasicCoffee());
		double cost = order.makeCoffee();
		assertEquals(4.49, cost, "wrong value");
	}
	@Test
	void testMulti() {
		Coffee order = new Cream( new ExtraShot(new BasicCoffee()));
		double cost = order.makeCoffee();
		assertEquals(5.69, cost, "wrong value");
	}
	@Test
	void testNew() {
		Coffee order = new Butter(new Cinnamon(new BasicCoffee()));
		double cost = order.makeCoffee();
		assertEquals(4.99, cost, "wrong value");
	}
	@Test
	void testSugar() {
		Coffee order = new Sugar(new BasicCoffee());
		double cost = order.makeCoffee();
		assertEquals(4.49, cost, "wrong value");
	}
	@Test
	void testExtra() {
		Coffee order = new ExtraShot(new BasicCoffee());
		double cost = order.makeCoffee();
		assertEquals(5.19, cost, "wrong value");
	}
	@Test
	void testAll() {
		Coffee order = new Cinnamon(new Butter(new Sugar(new Cream( new ExtraShot(new BasicCoffee())))));
		double cost = order.makeCoffee();
		assertEquals(7.19, cost, "wrong value");
	}
	@Test
	void testOriginal() {
		Coffee order = new Sugar(new Cream( new ExtraShot(new BasicCoffee())));
		double cost = order.makeCoffee();
		assertEquals(6.19, cost, "wrong value");
	}
	@Test
	void testRecursive() {
		Coffee order = new BasicCoffee();
		order = new Cream(order);
		order = new Butter(order);
		order = new Cinnamon(order);
		double cost = order.makeCoffee();
		assertEquals(5.49, cost, "wrong value");
	}
	@Test
	void testReset() {
		Coffee order = new Sugar(new BasicCoffee());
		order = new BasicCoffee();
		double cost = order.makeCoffee();
		assertEquals(3.99, cost, "wrong value");
	}

}
