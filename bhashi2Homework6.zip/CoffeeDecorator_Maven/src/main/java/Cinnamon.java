
public class Cinnamon extends CoffeeDecorator {

	private double cost = .50;
	Cinnamon(Coffee specialCoffee){
		super(specialCoffee);
	}
	
	public double makeCoffee() {
		return specialCoffee.makeCoffee() + addCinnamon();
	}
	
	private double addCinnamon() {
		
		System.out.println(" + cinnamon: $.50");
		
		return cost;
	}
}
