import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;

public class controller implements Initializable {

	@FXML
	private Button b1;
	@FXML
	private Button b2;
	@FXML
	private Button b3;
	@FXML
	private Button b4;
	@FXML
	private Button b5;
	@FXML
	private Button b6;
	@FXML
	private Button b7;
	@FXML
	private Button b8;
	@FXML
	private TextField t1;
	@FXML
	private TextField t2;
	@FXML
	private BorderPane bp;
	
	Coffee order;
	@Override
	public void initialize(URL location, ResourceBundle resources) {
		// TODO Auto-generated method stub
		t1.setEditable(false);
		t1.setText("Start your order with new order");
	}
	
	//new
	public void b1Method(ActionEvent e) throws IOException {
		order = new BasicCoffee();
		t1.setText("Black Coffee: $3.99");
	}
	//delete
	public void b2Method(ActionEvent e) throws IOException {
		order = null;
		t1.setText("Order deleted, start a new order");
	}
	//add cream
	public void b3Method(ActionEvent e) throws IOException {
		order = new Cream(order);
		t1.appendText(" + cream: $0.50");
	}
	//add sugar
	public void b4Method(ActionEvent e) throws IOException {
		order = new Sugar(order);
		t1.appendText(" + sugar: $0.50");
	}
	//add extra shots
	public void b5Method(ActionEvent e) throws IOException {
		order = new ExtraShot(order);
		t1.appendText("+ extra shot: $1.20");
	}
	//add cinnamon
	public void b6Method(ActionEvent e) throws IOException {
		order = new Cinnamon(order);
		t1.appendText(" + cinnamon: $0.50");
	}
	//add butter
	public void b7Method(ActionEvent e) throws IOException {
		order = new Butter(order);
		t1.appendText(" + butter: $0.50");
	}
	//final
	public void b8Method(ActionEvent e) throws IOException {
		double cost = order.makeCoffee();
		t1.appendText(": Total: " + cost);
	}
	
	
	
}
