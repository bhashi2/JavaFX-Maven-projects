
public class Butter extends CoffeeDecorator {
	private double cost = .50;
	Butter(Coffee specialCoffee){
		super(specialCoffee);
	}
	
	public double makeCoffee() {
		return specialCoffee.makeCoffee() + addButter();
	}
	
	private double addButter() {
		
		System.out.println(" + butter: $.50");
		
		return cost;
	}
}
