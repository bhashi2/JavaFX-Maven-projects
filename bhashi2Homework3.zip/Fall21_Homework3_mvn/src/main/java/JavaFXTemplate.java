import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class JavaFXTemplate extends Application {

	private Button b1;
	private Button b2;
	private TextField t1;
	private TextField t2;
	private BorderPane bp;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Bilal Hashim Homework 3");
		bp = new BorderPane();
		
		b1 = new Button("button 1");
		b2 = new Button("button 2");
		t1 = new TextField();
		t1.setPromptText("enter text here then press button 1");
		t2 = new TextField("final string goes here");
		t2.setEditable(false);
		
		//anonymous function
		b1.setOnAction(new EventHandler<ActionEvent>() {
			public void handle (ActionEvent e) {
				String t1Text = t1.getText();
				t2.setText(t1Text + " : from the center text field");
				b1.setText("pressed");
				b1.setDisable(true);
			}
		});
		
		//lambda function
		b2.setOnAction(e-> { 
			t1.clear();
			t2.setText("final string goes here");
			b1.setDisable(false);
			b1.setText("button 1");
		});
		
		bp.setCenter(t1);
		bp.setRight(t2);
		bp.setLeft(new VBox(20, b1, b2));
		bp.setStyle("-fx-background-color: gray");
		Scene scene = new Scene(bp, 800, 300);
		//Scene scene = new Scene(new VBox(20, b1, b2, t1, t2), 700,700);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

}
