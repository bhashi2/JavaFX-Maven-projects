import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;

import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyTest {
	
	@Test
	void makeCat() {
		AnimalFactory factory = new AnimalFactory();
		Animal cat = factory.make("Cat");
		assertEquals("Cat", cat.animalType(), "wrong type of animal");
	}
	
	@Test
	void catTalk() {
		AnimalFactory factory = new AnimalFactory();
		Animal cat = factory.make("Cat");
		assertEquals("meow", cat.talk(), "wrong sound");
	}
	
	@Test
	void catTalk2() {
		AnimalFactory factory = new AnimalFactory();
		Animal cat = factory.make("Cat");
		assertEquals("purr", cat.talk2(), "wrong sound");
	}
	
	@Test
	void makeDog() {
		AnimalFactory factory = new AnimalFactory();
		Animal dog = factory.make("Dog");
		assertEquals("Dog", dog.animalType(), "wrong type of animal");
	}
	
	@Test
	void dogTalk() {
		AnimalFactory factory = new AnimalFactory();
		Animal dog = factory.make("Dog");
		assertEquals("bark", dog.talk(), "wrong sound");
	}
	
	@Test
	void dogTalk2() {
		AnimalFactory factory = new AnimalFactory();
		Animal dog = factory.make("Dog");
		assertEquals("woof", dog.talk2(), "wrong sound");
	}
	
	@Test
	void makeMonkey() {
		AnimalFactory factory = new AnimalFactory();
		Animal monkey = factory.make("Monkey");
		assertEquals("Monkey", monkey.animalType(), "wrong type of animal");
	}
	
	@Test
	void monkeyTalk() {
		AnimalFactory factory = new AnimalFactory();
		Animal monkey = factory.make("Monkey");
		assertEquals("ooh ooh ahh ahh", monkey.talk(), "wrong sound");
	}
	
	@Test
	void monkeyTalk2() {
		AnimalFactory factory = new AnimalFactory();
		Animal monkey = factory.make("Monkey");
		assertEquals("ooh ooh", monkey.talk2(), "wrong sound");
	}
	
	@Test
	void testFactory() {
		AnimalFactory factory = new AnimalFactory();
		Animal cat = factory.make("Cat");
		Animal dog = factory.make("Dog");
		Animal monkey = factory.make("Monkey");
		
		assertEquals("Monkey", monkey.animalType(), "wrong animal");
		
	}
}
