import java.io.FileInputStream;

import javafx.application.Application;

import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class JavaFXTemplate extends Application {
	
	private Button b1;
	private Button b2;
	private Button b3;
	private TextField t1;
	private TextField t2;
	private Image catI; //for the cat image its my cat (:
	private Image dogI;
	private Image monkeyI;
	private ImageView view;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Homework 4");
		
		b1 = new Button("Make Cat");
		b2 = new Button("Make Dog");
		b3 = new Button("Make Monkey");
		t1 = new TextField("press a button to make an animal");
		t1.setEditable(false);
		t2 = new TextField("");
		t2.setEditable(false);
		catI = new Image("Cat.jpg");
		dogI = new Image("Dog.jpg");
		monkeyI = new Image("Monkey.jpg");
		view = new ImageView();
		view.setFitHeight(800);
		view.setFitWidth(640);
		view.setPreserveRatio(true);
		AnimalFactory factory = new AnimalFactory();
		
		b1.setOnAction(e-> {
			Animal cat = factory.make("Cat");
			view.setImage(catI);
			t1.setText("made cat");
			t2.setText(cat.talk());
		});
		
		b2.setOnAction(e-> {
			Animal dog = factory.make("Dog");
			view.setImage(dogI);
			t1.setText("made dog");
			t2.setText(dog.talk());
		});
		
		b3.setOnAction(e-> {
			Animal monkey = factory.make("Monkey");
			view.setImage(monkeyI);
			t1.setText("made monkey");
			t2.setText(monkey.talk());
		});
		
		Scene scene = new Scene(new VBox(20, t1, b1, b2, b3, t2, view), 800,700);
		primaryStage.setScene(scene);
		primaryStage.show();
	}

}
