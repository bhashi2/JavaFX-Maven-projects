
public interface Animal {
	String animalType();
	String talk();
	String talk2();
}

class Cat implements Animal {
	@Override
	public String animalType() {
		return "Cat";
	}

	@Override
	public String talk() {
		return "meow";
	}
	
	@Override
	public String talk2() {
		return "purr";
	}
}

class Dog implements Animal {
	@Override
	public String animalType() {
		return "Dog";
	}

	@Override
	public String talk() {
		return "bark";
	}
	
	@Override
	public String talk2() {
		return "woof";
	}
}

class Monkey implements Animal {
	@Override
	public String animalType() {
		return "Monkey";
	}

	@Override
	public String talk() {
		return "ooh ooh ahh ahh";
	}
	
	@Override
	public String talk2() {
		return "ooh ooh";
	}
}

interface AbstractFactory<T> {
	T make(String animalType);
}

class AnimalFactory implements AbstractFactory<Animal> {

	@Override
	public Animal make(String animalType) {
		if(("Cat").equals(animalType)) {
			return new Cat();
		}
		if("Dog".equals(animalType)) {
			return new Dog();
		}
		if("Monkey".equals(animalType)) {
			return new Monkey();
		}
		
		return null;
	}
	
}


