
public class SavingsFormulas {
	//FV = cash * (1+interest)^years
	public static double futureValueLumpSum(double cash, double interest, int years) {
		double step1 = (1+interest); //(1+i)
		double step2 = Math.pow(step1, years); //(1+i)^N
		double FV = cash * step2; //PV(1+i)^N
		return FV;
	}
	
	//cash = cash(1+values[i]) for all values 
	public static double futureValueLS_VariableInterest(double cash, double values[]) {
		int size = values.length;
		double total = cash;
		for(int i = 0; i < size; i++) {
			total = total * (1 + values[i]);
		}
		return total;
	}
	
	//FV = pmt((1+i)^N-1/i)
	public static double compoundSavingsConstant(double cash, double interest, int years) {
		double inner = (1+interest); //(1+i)
		double exponent = Math.pow(inner, years); //(1+i)^N
		double divide = (exponent - 1)/interest; //((1+i)^N - 1)/i 
		double total = cash * divide; //cash * (((1+i)^N - 1)/i)
		return total;
	}
	
	//year1 = values[0]
	//year2 = (year1 * interest) + values[i] for all values
	public static double compoundSavingsVariable(double values[], double interest) {
		int size = values.length;
		double total = values[0]; //year 1 = values[0]
		for(int i = 1; i < size; i++) {
			total += (total * interest) + values[i]; // yeari+1 = total*interest + values[i] 
		}
		return total;
	}
}
