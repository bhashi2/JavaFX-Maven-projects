import java.util.ArrayList;
import java.util.Arrays;

public class GameLogic {
	private int[][] deck;
	private int length = 16;
	
	private int[] goalState = {0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15};	//goal state used for comparison
	private int[] currentBoard;
	
	public GameLogic() {
		deck = new int[10][];
		deck[0] = new int[] {2, 6, 10, 3, 1, 4, 7, 11, 8, 5, 9, 15, 12, 13, 14, 0};
		deck[1] = new int[] {0, 10, 3, 11, 5, 1, 4, 14, 8, 2, 13, 7, 15, 6, 12, 9};
		deck[2] = new int[] {1, 3, 0, 4, 6, 2, 10, 5, 7, 9, 8, 11, 13, 14, 15, 12};
		deck[3] = new int[] {2, 6, 10, 3, 1, 4, 7, 11, 8, 0, 9, 15, 12, 5, 13, 14};
		deck[4] = new int[] {2, 6, 10, 3,1, 4, 0, 11, 8, 5, 7, 15, 12, 13, 9, 14};
		deck[5] = new int[] {2, 0, 10, 3, 1, 6, 4, 11, 8, 5, 7, 15, 12, 13, 9, 14};
		deck[6] = new int[] {0, 6, 10, 3, 2, 5, 4, 11, 1, 13, 7, 15, 8, 12, 9, 14};
		deck[7] = new int[] {5, 0, 10, 3, 1, 2, 4, 11, 8, 6, 7, 15, 12, 13, 9, 14};
		deck[8] = new int[] {5, 10, 4, 3, 1, 2, 7, 11, 8, 6, 15, 14, 12, 0, 13, 9};
		deck[9] = new int[] {10, 2, 3, 11, 5, 6, 4, 14, 1, 15, 0, 7, 8, 12, 13, 9};
		
		currentBoard = deck[0];
	}
	
	//sets the board 
	public void setBoard(int gameNum) {
		currentBoard = deck[gameNum];
	}
	
	//returns the board
	public int[] getBoard() {
		return currentBoard;
	}
	
	//finds where 0, the movable piece is on the board, returns -1 if something is wrong
	public int findZero() {
		int error = -1;
		for(int i = 0; i < length; i++) {
			if(currentBoard[i] == 0) {
				return i;
			}
		}
		
		return error;
	}
	//swaps the 0 piece with the left piece 
	public int[] swapLeft() {
		int ind = findZero();
		if(ind == 0 || ind == 4 || ind == 8 || ind == 12) {
			return currentBoard;
		}
		int temp = currentBoard[ind - 1];
		currentBoard[ind - 1] = currentBoard[ind];
		currentBoard[ind] = temp;
		return currentBoard;
	}
	
	public int[] swapRight() {
		int i = findZero();
		if(i == 3 || i == 7 || i == 11 || i == 15) {
			return currentBoard;
		}
		int temp = currentBoard[i + 1];
		currentBoard[i + 1] = currentBoard[i];
		currentBoard[i] = temp;
		return currentBoard;
	}
	
	public int[] swapUp() {
		int i = findZero();
		if(i + 4 > 15) {
			return currentBoard;
		}
		
		int temp = currentBoard[i + 4];
		currentBoard[i+4] = currentBoard[i];
		currentBoard[i] = temp;
		return currentBoard;
	}
	public int[] swapDown() {
		int i = findZero();
		if(i - 4 < 0) {
			return currentBoard;
		}
		
		int temp = currentBoard[i - 4];
		currentBoard[i-4] = currentBoard[i];
		currentBoard[i] = temp;
		return currentBoard;
	}
	
	public void printBoard() {
		for(int i = 0; i < length; i++) {
			System.out.printf("%4d ", currentBoard[i]);
			if(i == 3 || i == 7 || i == 11)
				System.out.print("\n");
		}
	}
	
	public boolean checkWin() {
		for(int i = 0; i < length; i++) {
			if(currentBoard[i] != i) {
				return false;
			}
		}
		return true;
	}
	
	public int getInd(int i) {
		return currentBoard[i];
	}
	
	public ArrayList A_Star(Node startState, String heuristic){
		
		
		DB_Solver2 start_A_Star = new DB_Solver2(startState, heuristic);	//DB_Solver class initialized with startState node
		
				
		Long start = System.currentTimeMillis();

		Node solution = start_A_Star.findSolutionPath();	//returns the node that contains the solved puzzle
		
		Long end = System.currentTimeMillis();

		System.out.println("\n******Run Time for A* "+ heuristic + " is: "+ (end-start) + " milliseconds**********");
		
		if(solution == null)								//no solution was found
		{
			System.out.println("\nThere did not exist a solution to your puzzle with A* search\n");
		}
		else											//found a solution so, get the path and print it
		{
			ArrayList<Node> solutionPath = start_A_Star.getSolutionPath(solution);	//creates ArrayList of solution path
			return solutionPath;
			//printSolution(solutionPath);
			
			//System.out.println("\n$$$$$$$$$$$$$$ the solution path is "+ solutionPath.size()+ " moves long\n");
		}
		return null;
	}
	
}