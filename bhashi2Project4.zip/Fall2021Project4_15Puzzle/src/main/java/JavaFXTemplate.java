import javafx.application.Application;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class JavaFXTemplate extends Application {
	
	GameLogic game = new GameLogic();
	int gameNum = 0;
	private GridPane grid;
	private TextField t1;
	private Button zero;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

	//feel free to remove the starter code from this method
	@Override
	public void start(Stage primaryStage) throws Exception {
		// TODO Auto-generated method stub
		primaryStage.setTitle("Welcome to JavaFX");
		Button H1 = new Button("H1");
		Button H2 = new Button("H2");
		Button next = new Button("Another Board");
		Button checkWin = new Button("Check Win");
		Button exit = new Button("Exit");
		Button seeSolution = new Button("See Solution");
		seeSolution.setDisable(true);

		t1 = new TextField("Click a button next to button 0 to swap them");
		t1.setEditable(false);
		
		VBox root = new VBox();
		root.getChildren().addAll(makeGrid(), t1, H1, H2, seeSolution, next, checkWin, exit);
		next.setOnAction(e->{
			gameNum++;
			if(gameNum > 9) {
				gameNum = 0;
			}
			game.setBoard(gameNum);
			root.getChildren().clear();
			root.getChildren().addAll(makeGrid(), t1, H1, H2, seeSolution, next, checkWin, exit);
		});
		checkWin.setOnAction(e->{
			boolean win = game.checkWin();
			if(win) {
				t1.setText("you solved it!");
			} else {
				t1.setText("keep trying!");
			}
		});
		exit.setOnAction(e->{
			System.out.println("exiting...");
			System.exit(1);
		});
		H1.setOnAction(e->{
			/*
			Node startState = new Node(game.getBoard());
			game.A_Star(startState, "heuristicOne");
			*/
			seeSolution.setDisable(false);
		});
		H2.setOnAction(e-> {
			seeSolution.setDisable(false);
		});
		
		Scene scene = new Scene(root, 700,700);
		scene.getStylesheets().add("/styles/style1.css");
		primaryStage.setScene(scene);
		primaryStage.show();
		
		//Thread t = new Thread(()-> {A_IDS_A_15solver ids = new A_IDS_A_15solver();});
		//t.start();
		

	}
	
	private Pane makeGrid() {
		grid = new GridPane();
		int counter = 0;
		for(int i = 0; i < 4; i++) {
			for(int j = 0; j < 4; j++) {
				Button b = new Button("" + game.getInd(counter));
				if(game.getInd(counter) == 0) {
					zero = b;
				}
				grid.add(b, j, i);
				b.setOnAction(e->buttonClicked(b));
				counter++;
			}
		}
		return grid;
	}
	
	private void buttonClicked(Button b) {
		// TODO Auto-generated method stub
		//b.setText("clicked");
		int i = game.findZero();
		int row = GridPane.getRowIndex(b);
		int col = GridPane.getColumnIndex(b);
		int ind = (row * 4) + col;
		
		if(i + 1 == ind) {
			game.swapRight();
			game.printBoard();
			System.out.println("\n");
			String temp = zero.getText();
			zero.setText(b.getText());
			b.setText(temp);
		} else if(i - 1 == ind) {
			game.swapLeft();
			game.printBoard();
			System.out.println("\n");
			String temp = zero.getText();
			zero.setText(b.getText());
			b.setText(temp);
		} else if(i + 4 == ind) {
			game.swapUp();
			game.printBoard();
			System.out.println("\n");
			String temp = zero.getText();
			zero.setText(b.getText());
			b.setText(temp);
		} else if(i - 4 == ind) {
			game.swapDown();
			game.printBoard();
			System.out.println("\n");
			String temp = zero.getText();
			zero.setText(b.getText());
			b.setText(temp);
		} else {
			t1.setText("try again, has to be next to button 0");
			return;
		}
		t1.setText("keep going!");
		zero = b;
		boolean won = game.checkWin();
		if(won) {
			t1.setText("you won!");
		}
	}
	
}
