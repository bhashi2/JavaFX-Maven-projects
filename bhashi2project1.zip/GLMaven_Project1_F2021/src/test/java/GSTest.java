import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class GSTest {
	
	@Test //test T types Integer and String
	void testTypes() {
		GenericStack<Integer> s1 = new GenericStack<Integer>();
		GenericStack<String> s2 = new GenericStack<String>();
		s1.add(1);
		s2.add("one");
		assertEquals(1, s1.get(0), "not 1");
		assertEquals("one", s2.get(0), "not one");
	}
	
	@Test //testing if correct length, also tests 1 add
	void testLength() {
		GenericStack<Integer> s1 = new GenericStack<Integer>();
		assertEquals(0, s1.getLength(), "wrong length");
		
		s1.add(3);
		assertEquals(1, s1.getLength(), "wrong length");
	}
	
	@Test //tests the get function and add
	void testGet() {
		GenericStack<Integer> s1 = new GenericStack<Integer>();
		s1.add(1);
		System.out.println("in test get");
		assertEquals(1, s1.get(0), "get got the wrong number");
	}
	
	@Test //test add and push(which calls add)
	void testAdd() {
		GenericStack<Integer> s1 = new GenericStack<Integer>();
		s1.add(0);
		s1.add(1);
		s1.add(2);
		s1.push(3);
		Integer arr[] = {0, 1, 2, 3}; 
		Integer[] arr2 = new Integer[4];
		for(int i = 0; i < 4; i++) {
			arr2[i] = s1.get(i);
		}
		assertArrayEquals(arr, arr2, "wrong values");
	}
	
	@Test //tests delete (which also tests dequeue and pop) and length
	void testDelete() {
		GenericStack<String> s1 = new GenericStack<String>();
		s1.add("string 0");
		s1.add("string 1");
		s1.delete();
		assertEquals(1, s1.getLength(), "wrong length");
	}
	
	@Test //tests dumplist
	void testDumpList() {
		ArrayList<Integer> arr = new ArrayList<Integer>();
		ArrayList<Integer> dump = new ArrayList<Integer>();
		GenericStack<Integer> s = new GenericStack<Integer>();
		for(int i = 0; i < 5; i++) {
			arr.add(i);
			s.add(i);
		}
		dump = s.dumpList();
		assertEquals(arr, dump, "did not dump correctly");
	}
	
	@Test //tests set
	void testSet() {
		GenericStack<Integer> s = new GenericStack<Integer>();
		s.add(0);
		s.add(1);
		s.add(2);
		s.set(1, 3);
		assertEquals(3, s.get(1));
	}
	
	@Test //tests remove tail
	void testRemoveTail() {
		GenericStack<Integer> s = new GenericStack<Integer>();
		s.add(0);
		s.add(1);
		s.add(2);
		int tail = s.removeTail();
		
		assertEquals(2, tail, "wrong num deleted");
		assertEquals(2, s.getLength(), "wrong length");
	}
	
	@Test //test for each loop
	void testForEach() {
		GenericStack<Integer> s = new GenericStack<Integer>();
		s.add(0);
		s.add(1);
		s.add(2);
		int arr[] = {0, 1, 2};
		int i = 0;
		int arr2[] = new int[3];
		for (Integer e : s) {
            arr2[i] = e;
            i++;
		}
		assertArrayEquals(arr, arr2, "wrong values");
	}
	
}
