import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class GQTest {

	
	@Test //test T types Integer and String
	void testTypes() {
		GenericQueue<Integer> s1 = new GenericQueue<Integer>();
		GenericQueue<String> s2 = new GenericQueue<String>();
		s1.add(1);
		s2.add("one");
		assertEquals(1, s1.get(0), "not 1");
		assertEquals("one", s2.get(0), "not one");
	}
	
	
	@Test //testing if correct length, also tests 1 add
	void testLength() {
		GenericQueue<Integer> s1 = new GenericQueue<Integer>();
		assertEquals(0, s1.getLength(), "wrong length");
		
		s1.add(3);
		assertEquals(1, s1.getLength(), "wrong length");
	}
	
	@Test //tests the get function and add
	void testGet() {
		GenericQueue<Integer> s1 = new GenericQueue<Integer>();
		s1.add(1);
		System.out.println("in test get");
		assertEquals(1, s1.get(0), "get got the wrong number");
	}
	
	@Test //test add and enqueue(which calls add)
	void testAdd() {
		GenericQueue<Integer> s1 = new GenericQueue<Integer>();
		s1.add(0);
		s1.add(1);
		s1.add(2);
		s1.enqueue(3);
		Integer arr[] = {3, 2, 1, 0}; 
		Integer[] arr2 = new Integer[4];
		for(int i = 0; i < 4; i++) {
			arr2[i] = s1.get(i);
		}
		assertArrayEquals(arr, arr2, "wrong values");
	}
	
	@Test //tests delete and length
	void testDelete() {
		GenericQueue<String> s1 = new GenericQueue<String>();
		s1.add("string 0");
		s1.add("string 1");
		s1.delete();
		assertEquals(1, s1.getLength(), "wrong length");
	}
	
	@Test //tests dumplist
	void testDumpList() {
		ArrayList<Integer> arr = new ArrayList<Integer>();
		ArrayList<Integer> dump = new ArrayList<Integer>();
		GenericQueue<Integer> s = new GenericQueue<Integer>();
		for(int i = 0; i < 5; i++) {
			arr.add(4-i);
			s.add(i);
		}
		dump = s.dumpList();
		assertEquals(arr, dump, "did not dump correctly");
	}
	
	@Test //tests set
	void testSet() {
		GenericQueue<Integer> s = new GenericQueue<Integer>();
		s.add(0);
		s.add(1);
		s.add(2);
		s.set(1, 3);
		assertEquals(3, s.get(1));
	}
	
	@Test //tests remove tail
	void testRemoveTail() {
		GenericQueue<Integer> s = new GenericQueue<Integer>();
		s.add(0);
		s.add(1);
		s.add(2);
		int tail = s.removeTail();
		
		assertEquals(0, tail, "wrong num deleted");
		assertEquals(2, s.getLength(), "wrong length");
	}
	
	@Test //test for each loop
	void testForEach() {
		GenericQueue<Integer> s = new GenericQueue<Integer>();
		s.add(0);
		s.add(1);
		s.add(2);
		int arr[] = {2, 1, 0};
		int i = 0;
		int arr2[] = new int[3];
		for (Integer e : s) {
            arr2[i] = e;
            i++;
		}
		assertArrayEquals(arr, arr2, "wrong values");
	}
	
}

