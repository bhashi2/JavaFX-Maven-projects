// Bilal Hashim
// bhashi2
// bhashi2@uic.edu
// develop my own version of the stack and queue data structures in
// a way that can be used in other projects

public class GLProject {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to project 1");
		/*
		GenericStack<String> myStack = new GenericStack<>();
		myStack.add("string 1");
		myStack.add("string 2");
		myStack.add("string 3");
		
		myStack.print();
		for (String string : myStack)
            System.out.println(string);
		myStack.dumpList();
		myStack.print();
		//System.out.println(myStack.getTail());
		 
		/*
		GenericQueue<Integer> myQueue = new GenericQueue<>();
		myQueue.add(0);
		myQueue.add(1);
		myQueue.add(2);
		myQueue.add(3);
		myQueue.add(4);
		myQueue.delete();		
		myQueue.set(0, 31);
		myQueue.set(2, 100);
		Integer t3  = myQueue.removeTail();
		myQueue.print();
		System.out.println(myQueue.getLength());
		*/
	}
}
