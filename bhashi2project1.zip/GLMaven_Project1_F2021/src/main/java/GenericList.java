import java.util.Iterator;
import java.util.ArrayList;

public abstract class GenericList<T> implements Iterable<T> {
	private Node<T> head;
	private int length;
	
	//the node class that creates each node, also has getters and setters
	public class Node<T> {
		private T data;
		private Node<T> next;
		
		public Node(T val) {
			this.data = val;
		}
		
		public T getData() {
			return this.data;
		}
		public Node<T> getNext() {
			return this.next;
		}
		public void setData(T val) {
			this.data = val;
		}
		public void setNext(Node<T> next) {
			this.next = next;
		}
	}
	
	//print out the list
	public void print() {
		if(head == null) {
			System.out.println("no elements");
			return;
		}
		Node<T> temp = head;
		while(temp != null) {
			System.out.println(temp.getData()); 
			temp = temp.getNext();
		}
	}
	
	//add is abstract because it depends on add order
	public abstract void add(T data);
	
	//return first node and delete it return null otherwise
	public T delete() {
		if(head == null) {
			return null;
		} else if(head.getNext() == null) {
			T data = head.getData();
			head = null;
			return data;
		}
		T val = head.getData();
		head = head.getNext();
		setLength(getLength() - 1);
		return val;
	}
	
	//removes each value of the list and puts it into the array list
	public ArrayList<T> dumpList() {
		ArrayList<T> dump = new ArrayList<T>();
		Node<T> temp = head;
		while(temp != null) {
			dump.add(delete());
			temp = temp.getNext();
		}
		return dump;
	}
	
	//get the value at that index
	public T get(int i) {
		if(head == null) {
			return null;
		}
		int counter = 0;
		Node<T> temp = head;
		while(counter != i) {
			temp = temp.getNext();
			counter++;
		}
		if(temp == null) {
			return null;
		}
		return temp.getData();
	}
	
	//replace the element at the index
	public T set(int i, T val) {
		if(head == null) {
			return null;
		}
		int counter = 0;
		Node<T> temp = head;
		while(counter != i) {
			temp = temp.getNext();
			counter++;
		}
		if(temp == null) {
			return null;
		}
		T data = temp.getData();
		temp.setData(val);
		return data;		
	}
	
	
	//getter setters
	public int getLength() {
		return length;
	}
	public void setLength(int length) {
		this.length = length;
	}
	public Node<T> getHead() {
		return head;
	}
	public void setHead(Node<T> val) {
		this.head = val;
	}
	
	public Iterator<T> iterator() {
        return new GLLIterator<T>(this);
    }
	
}
