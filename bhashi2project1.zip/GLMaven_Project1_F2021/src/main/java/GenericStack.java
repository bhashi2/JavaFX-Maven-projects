
public class GenericStack<T> extends GenericList<T> {
	
	private Node<T> tail;
	
	//add node to the stack. updates tail and head as needed as well as length
	public void add(T data) {
		Node<T> node = new Node<>(data);
		Node<T> head = getHead();
		
		if(head == null) {
			tail = node;
			setHead(node);
		} else {
			tail.setNext(node);
			tail = node;
		}
		
		setLength(getLength() + 1);
	}
	
	//removes the tail and updates tail and length
	public T removeTail() {
		Node<T> temp = getHead();
		T data;
		if(temp == null) {
			return null;
		}
		if(temp.getNext() == null) {
			data = temp.getData();
			setHead(null);
			setLength(getLength() - 1);
			return data;
		}
		
		data = tail.getData();
		while(temp != null) {
			if(temp.getNext() == tail) {
				temp.setNext(null);
				tail = temp;
				setLength(getLength() - 1);
				return data;
			}
			temp = temp.getNext();
		}
		return data;
	}
	
	//alternative to add
	public void push(T data) {
		add(data);
	}
	
	//alternative to delete
	public T pop() {
		return delete();
	}
	
}
