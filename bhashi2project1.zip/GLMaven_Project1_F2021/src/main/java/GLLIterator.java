import java.util.Iterator;

public class GLLIterator<T> implements Iterator<T>{
	GenericList<T>.Node<T> temp;
	
	//the constructor 
	public GLLIterator(GenericList<T> list){
		temp = list.getHead();
	}
	
	//checks if the linked list has a next node
	@Override
	public boolean hasNext() {
		return temp != null;
	}
	
	//goes to the next node as well as returning the original nodes value
	@Override
	public T next() {
		T data = temp.getData();
		temp = temp.getNext();
		return data;
	}
}
