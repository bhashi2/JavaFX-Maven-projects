import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class SavingsMethodTest {
	static MyMoney s1;
	static MyMoney s2;
	static MyMoney s3;
	
	@BeforeAll
	static void setup() {
		s1 = new MyMoney("values.txt", 8, 1);
		s2 = new MyMoney("values2.txt", 8, 2);
		s3 = new MyMoney("values.txt", "values2.txt", 8, 8);
	}
	
	@Test
	void futureValLumpSumTest() {
		
		//future value of $20,000 over 10 years at 7%
		assertEquals(39343,Math.round(SavingsFormulas.futureValueLumpSum(20000, .07, 10)), "wrong value");
	}
	
	@Test
	void futureValLumpSumTwoTest() {
		
		//future value of $10,000 over 5 years at 5%
		assertEquals(12763,Math.round(SavingsFormulas.futureValueLumpSum(10000, .05, 5)), "wrong value");
	}
	
	
	@Test
	void FVLSTest() {
		assertEquals(8027, Math.round(SavingsFormulas.futureValueLS_VariableInterest(5000, s2.getInterestValues())), "wrong value");
	}
	
	@Test
	void FVLSTest2() {
		assertEquals(1605, Math.round(SavingsFormulas.futureValueLS_VariableInterest(1000, s2.getInterestValues())), "wrong value");
	}
	
	@Test
	void constantSavingsTest() {
		
		//save $20,000 yearly at 7% for 10 years
		assertEquals(276329,Math.round(SavingsFormulas.compoundSavingsConstant(20000, .07, 10)), "wrong value");
	}
	
	@Test
	void constantSavingsTwoTest() {
		
		//save $1000 yearly at 5% for 5 years
		assertEquals(5526,Math.round(SavingsFormulas.compoundSavingsConstant(1000, .05, 5)), "wrong value");
	}
	
	
	@Test
	void CSVTest() {
		assertEquals(24461, Math.round(SavingsFormulas.compoundSavingsVariable(s1.getCashValues(), 0.5)), "wrong value");
	}
	
	@Test
	void CSVTest2() {
		assertEquals(12823, Math.round(SavingsFormulas.compoundSavingsVariable(s1.getCashValues(), 0.07)), "wrong value");
	}
	
}


