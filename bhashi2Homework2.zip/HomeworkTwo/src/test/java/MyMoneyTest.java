import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;

class MyMoneyTest {
	static MyMoney s1;
	static MyMoney s2;
	static MyMoney s3;
	private static int i = 0;
	@BeforeAll
	static void setup() {
		s1 = new MyMoney("values.txt", 8, 1);
		s2 = new MyMoney("values2.txt", 8, 2);
		s3 = new MyMoney("values.txt", "values2.txt", 8, 8);
	}
	
	@ParameterizedTest
	@ValueSource (doubles = {4000, 5500, 15000, 18000, 24000, 9000, 11000, 12000})
	void paramTest(double val) {
		double arr1[] = s1.getCashValues();
		assertEquals(arr1[i], val, "wrong array values");
		i++;
	}
	
	@Test
	void array1Test() {
		double arr1[] = {4000, 5500, 15000, 18000, 24000, 9000, 11000, 12000};
		assertArrayEquals(arr1, s1.getCashValues(), "wrong array values");
	}
	
	@Test
	void array2Test() {
		double arr2[] = {0.055, 0.075, 0.045, 0.09, 0.10, 0.065, 0.035, 0.025};
		assertArrayEquals(arr2, s2.getInterestValues(), "wrong interest values");
	}
	
	@Test
	void array3Test() {
		double arr1[] = {4000, 5500, 15000, 18000, 24000, 9000, 11000, 12000};
		assertArrayEquals(arr1, s3.getCashValues(), "wrong cash values");
		
		double arr2[] = {0.055, 0.075, 0.045, 0.09, 0.10, 0.065, 0.035, 0.025};
		assertArrayEquals(arr2, s3.getInterestValues(), "wrong interest values");
	}

	@Test
	void lumpSumTest() {
		assertEquals(39343, Math.round(s1.lumpSum_ConstantRate(20000, 0.07, 10)), "wrong value");
	}
	
	@Test
	void lumpSumTest2() {
		assertEquals(12763, Math.round(s1.lumpSum_ConstantRate(10000, 0.05, 5)), "wrong value");
	}
	
	@Test
	void lumpSumVariableTest() {
		assertEquals(8027, Math.round(s2.lumpSum_VariableRate(5000)), "wrong value");
	}
	
	@Test
	void lumpSumVariableTest2() {
		assertEquals(1605, Math.round(s2.lumpSum_VariableRate(1000)), "wrong value");
	}
	
	@Test
	void CSsameC() {
		assertEquals(276329, Math.round(s1.compoundSavings_sameContribution(20000, 0.07, 10)), "wrong value");
	}
	
	@Test
	void CSsameC2() {
		assertEquals(5526, Math.round(s1.compoundSavings_sameContribution(1000, 0.05, 5)), "wrong value");
	}
	
	@Test
	void CSVariableC() {
		assertEquals(24461, Math.round(s1.compoundSavings_variableContribution(0.5)), "wrong value");
	}
	
	@Test
	void CSVariableC2() {
		assertEquals(12823, Math.round(s1.compoundSavings_variableContribution(0.07)), "wrong value");
	}
}
